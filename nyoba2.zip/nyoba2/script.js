// Main JavaScript file with jQuery
$(document).ready(function() {
    console.log('Book Borrowing System Ready!');
    
    // Initialize form interactions
    initializeForm();
    initializeAnimations();
    initializeValidation();
    
    // Initialize results page functionality if on results page
    if ($('#dataTable').length > 0) {
        initializeResultsPage();
    }
});

function initializeForm() {
    // Character counter for comment field
    $('#komentar').on('input', function() {
        const length = $(this).val().length;
        $('#char-count').text(length);
        
        if (length >= 10) {
            $('#char-count').css('color', '#28a745');
        } else {
            $('#char-count').css('color', '#e74c3c');
        }
    });
    
    // Reset button functionality
    $('#resetBtn').click(function() {
        resetForm();
    });
    
    // Form submission with validation
    $('#bookForm').submit(function(e) {
        e.preventDefault();
        
        if (validateForm()) {
            showLoading();
            
            // Simulate processing delay for better UX
            setTimeout(() => {
                this.submit();
            }, 1500);
        }
    });
}

function initializeAnimations() {
    // Hover effects for form elements
    $('.form-group input, .form-group select, .form-group textarea').hover(
        function() {
            $(this).css('transform', 'translateY(-1px)');
        },
        function() {
            if (!$(this).is(':focus')) {
                $(this).css('transform', 'translateY(0)');
            }
        }
    );
    
    // Button hover animations
    $('.btn').hover(
        function() {
            $(this).addClass('btn-hover');
        },
        function() {
            $(this).removeClass('btn-hover');
        }
    );
    
    // Form group focus animations
    $('.form-group input, .form-group select, .form-group textarea').focus(function() {
        $(this).parent().addClass('focused');
        $(this).css('transform', 'translateY(-2px)');
    }).blur(function() {
        $(this).parent().removeClass('focused');
        if (!$(this).is(':hover')) {
            $(this).css('transform', 'translateY(0)');
        }
    });
    
    // Animate form elements on scroll
    $(window).scroll(function() {
        $('.form-group').each(function() {
            const elementTop = $(this).offset().top;
            const elementBottom = elementTop + $(this).outerHeight();
            const viewportTop = $(window).scrollTop();
            const viewportBottom = viewportTop + $(window).height();
            
            if (elementBottom > viewportTop && elementTop < viewportBottom) {
                $(this).addClass('in-view');
            }
        });
    });
}

function initializeValidation() {
    // Real-time validation
    $('#nama').blur(function() {
        validateField('nama', $(this).val().trim() !== '', 'Nama harus diisi');
    });
    
    $('#email').blur(function() {
        const email = $(this).val().trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        validateField('email', emailRegex.test(email), 'Format email tidak valid');
    });
    
    $('#judul_buku').blur(function() {
        validateField('judul_buku', $(this).val().trim() !== '', 'Judul buku harus diisi');
    });
    
    $('#lama_peminjaman').change(function() {
        validateField('lama_peminjaman', $(this).val() !== '', 'Pilih lama peminjaman');
    });
    
    $('#komentar').blur(function() {
        const comment = $(this).val().trim();
        validateField('komentar', comment.length >= 10, 'Komentar harus minimal 10 karakter');
    });
}

function validateField(fieldName, isValid, errorMessage) {
    const errorElement = $(`#${fieldName}-error`);
    const inputElement = $(`#${fieldName}`);
    
    if (!isValid) {
        errorElement.text(errorMessage).addClass('show');
        inputElement.css('border-color', '#e74c3c');
        return false;
    } else {
        errorElement.removeClass('show');
        inputElement.css('border-color', '#28a745');
        return true;
    }
}

function validateForm() {
    let isValid = true;
    
    // Clear previous errors
    $('.error-message').removeClass('show');
    
    // Validate nama
    const nama = $('#nama').val().trim();
    if (nama === '') {
        validateField('nama', false, 'Nama harus diisi');
        isValid = false;
    }
    
    // Validate email
    const email = $('#email').val().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        validateField('email', false, 'Format email tidak valid');
        isValid = false;
    }
    
    // Validate judul buku
    const judulBuku = $('#judul_buku').val().trim();
    if (judulBuku === '') {
        validateField('judul_buku', false, 'Judul buku harus diisi');
        isValid = false;
    }
    
    // Validate lama peminjaman
    const lamaPeminjaman = $('#lama_peminjaman').val();
    if (lamaPeminjaman === '') {
        validateField('lama_peminjaman', false, 'Pilih lama peminjaman');
        isValid = false;
    }
    
    // Validate komentar
    const komentar = $('#komentar').val().trim();
    if (komentar.length < 10) {
        validateField('komentar', false, 'Komentar harus minimal 10 karakter');
        isValid = false;
    }
    
    // Show shake animation for invalid form
    if (!isValid) {
        $('.form-container').addClass('shake');
        setTimeout(() => {
            $('.form-container').removeClass('shake');
        }, 600);
    }
    
    return isValid;
}

function resetForm() {
    // Animate reset
    $('.form-container').fadeOut(300, function() {
        $('#bookForm')[0].reset();
        $('.error-message').removeClass('show');
        $('.form-group input, .form-group select, .form-group textarea').css('border-color', '#e1e5e9');
        $('#char-count').text('0').css('color', '#e74c3c');
        
        $(this).fadeIn(300);
    });
}

function showLoading() {
    $('#loadingOverlay').fadeIn(300);
}

function hideLoading() {
    $('#loadingOverlay').fadeOut(300);
}

// Results page functionality
function initializeResultsPage() {
    console.log('Initializing results page...');
    
    // Initialize search functionality
    initializeSearch();
    
    // Initialize table animations
    initializeTableAnimations();
    
    // Initialize modal functionality
    initializeModal();
}

function initializeSearch() {
    $('#searchInput').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        
        $('#dataTable tbody tr').each(function() {
            const rowText = $(this).text().toLowerCase();
            if (rowText.includes(searchTerm)) {
                $(this).fadeIn(300);
            } else {
                $(this).fadeOut(300);
            }
        });
    });
}

function initializeTableAnimations() {
    // Animate table rows on load
    $('#dataTable tbody tr').each(function(index) {
        $(this).css('opacity', '0').delay(index * 100).animate({
            opacity: 1
        }, 500);
    });
    
    // Hover effects for stat cards
    $('.stat-card').hover(
        function() {
            $(this).css('transform', 'translateY(-5px) scale(1.02)');
        },
        function() {
            $(this).css('transform', 'translateY(0) scale(1)');
        }
    );
}

function initializeModal() {
    // Close modal when clicking outside
    $(window).click(function(event) {
        if (event.target.id === 'commentModal') {
            closeModal();
        }
    });
    
    // Keyboard shortcuts
    $(document).keydown(function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
        if (e.ctrlKey && e.key === 'f') {
            e.preventDefault();
            $('#searchInput').focus();
        }
    });
}

function showFullComment(comment) {
    $('#fullComment').text(comment);
    $('#commentModal').fadeIn(300);
}

function closeModal() {
    $('#commentModal').fadeOut(300);
}

function exportData() {
    // Simple CSV export
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "ID,Nama,Email,Judul Buku,Lama Peminjaman,Tanggal Pinjam,Tanggal Kembali,Komentar,Status\n";
    
    $('#dataTable tbody tr').each(function() {
        const row = [];
        $(this).find('td').each(function(index) {
            if (index === 7) { // Comment column
                const commentText = $(this).find('.comment-preview').text().trim();
                row.push('"' + commentText.replace(/"/g, '""') + '"');
            } else {
                row.push('"' + $(this).text().trim().replace(/"/g, '""') + '"');
            }
        });
        csvContent += row.join(',') + '\n';
    });
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data_peminjaman_" + new Date().toISOString().split('T')[0] + ".csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Show success message
    alert('📊 Data berhasil diexport ke file CSV!');
}

// Global functions for onclick handlers
window.showFullComment = showFullComment;
window.closeModal = closeModal;
window.exportData = exportData;

// Additional CSS for animations
const additionalCSS = `
    .shake {
        animation: shake 0.6s ease-in-out;
    }
    
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
    
    .form-group.in-view {
        animation: slideInUp 0.6s ease-out;
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .btn-hover {
        transform: translateY(-3px) !important;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15) !important;
    }
`;

// Inject additional CSS
$('<style>').prop('type', 'text/css').html(additionalCSS).appendTo('head');